# hammadakhawaja.com

Portfolio site for Hammad A. Khawaja. React 18 + Vite 5 + React Router.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in dist/
```

Edit content in `src/data/site.js`. Project conventions and open items are in `CLAUDE.md`.
